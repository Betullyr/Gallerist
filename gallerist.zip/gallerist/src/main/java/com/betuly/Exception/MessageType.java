package com.betuly.Exception;

import lombok.Getter;

@Getter
public enum MessageType {

	NO_RECORD_EXIST("1004", "Kayıt Bulunmadı"),
	TOKEN_IS_EXPİRED("1005", "Token Süresi dolmuştur"),
	USER_NOT_FOUND("1006", "Kullanıcı bulunamadı"),
	USERNAME_OR_INVALID("1007", "Kullanıcı adı veya şifre hatalıdır"),
	REFRESH_TOKEN_NOT_FOUND("1008", "Refresh Token Bulunmadı"),
	REFRESH_TOKEN_IS_EXPIRED("1009", "Refresh Token Süresi Dolmuş"),
	CURRENCY_RATES_IS_OCCURED("1010", "Döviz kuru alınamadı"),
	CUSTOMER_AMOUNT_IS_ENOUGH("1011", "Müsterinin parası yetersiz"),
	CAR_IS_ALREADY_SALED("1011", "Araba satılmış"),
	GENERAL_EXCEPTION("9999", "Genel Hata Oluştu");
	
	
	private String code;
	
	private String message;
	
	MessageType(String code, String message) {
		this.code = code;
		this.message = message;
	}
	
	
}
