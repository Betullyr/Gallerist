package com.betuly.controller;

import com.betuly.dto.DtoAccount;
import com.betuly.dto.DtoAccountIU;


public interface IRestAccountController {
	
	public RootEntity<DtoAccount> saveAccount(DtoAccountIU dtoAccountIU);
 
}
