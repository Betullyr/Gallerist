package com.betuly.controller;

import com.betuly.dto.DtoAddress;
import com.betuly.dto.DtoAddressIU;

public interface IRestAddressController {
	
	public RootEntity<DtoAddress> saveAddress(DtoAddressIU dtoAddressIU);

}
