package com.betuly.controller;

import com.betuly.dto.AuthRequest;
import com.betuly.dto.AuthResponse;
import com.betuly.dto.DtoUser;
import com.betuly.dto.RefreshTokenRequest;

public interface IRestAuthenticationController {
	
	public RootEntity<DtoUser> register(AuthRequest input); 
	
	public RootEntity<AuthResponse> authenticate(AuthRequest input);
	
	
	public RootEntity<AuthResponse> refreshToken(RefreshTokenRequest input);
	
	

}
