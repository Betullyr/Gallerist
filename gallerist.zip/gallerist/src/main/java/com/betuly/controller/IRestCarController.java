package com.betuly.controller;

import com.betuly.dto.DtoCar;
import com.betuly.dto.DtoCarIU;

public interface IRestCarController {
	
	public RootEntity<DtoCar> saveCar(DtoCarIU dtoCarIU);

}
