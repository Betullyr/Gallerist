package com.betuly.controller;

import com.betuly.dto.DtoCustomer;
import com.betuly.dto.DtoCustomerIU;

public interface IRestCustomerController {
	
	public RootEntity<DtoCustomer> saveCustomer(DtoCustomerIU dtoCustomerIU);

}
