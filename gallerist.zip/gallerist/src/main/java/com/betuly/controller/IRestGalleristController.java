package com.betuly.controller;

import com.betuly.dto.DtoGallerist;
import com.betuly.dto.DtoGalleristIU;

public interface IRestGalleristController {
	
	public RootEntity<DtoGallerist> saveGallerist(DtoGalleristIU dtoGalleristIU);

}
