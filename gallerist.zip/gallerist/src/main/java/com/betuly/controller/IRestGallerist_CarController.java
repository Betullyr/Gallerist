package com.betuly.controller;

import com.betuly.dto.DtoGallerist_car;
import com.betuly.dto.DtoGallerist_carIU;

public interface IRestGallerist_CarController {
	
	public RootEntity<DtoGallerist_car> saveGallerist_Car(DtoGallerist_carIU dtoGallerist_carIU);

}
