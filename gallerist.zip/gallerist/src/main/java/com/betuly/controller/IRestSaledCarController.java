package com.betuly.controller;

import com.betuly.dto.DtoSaledCar;
import com.betuly.dto.DtoSaledCarIU;

public interface IRestSaledCarController {
	
	public RootEntity<DtoSaledCar> buyCar(DtoSaledCarIU dtoSaledCarIU);

}
