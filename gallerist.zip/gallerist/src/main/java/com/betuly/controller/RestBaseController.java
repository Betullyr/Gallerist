package com.betuly.controller;

public class RestBaseController {
	
	public static <T> RootEntity<T> ok(T payload){
		return RootEntity.ok(payload);
	}
	
	public static <T> RootEntity<T> error(String errorMessage){
		return RootEntity.error(errorMessage);
	}

}
