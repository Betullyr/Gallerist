package com.betuly.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.betuly.controller.IRestAccountController;
import com.betuly.controller.RestBaseController;
import com.betuly.controller.RootEntity;
import com.betuly.dto.DtoAccount;
import com.betuly.dto.DtoAccountIU;
import com.betuly.service.IAccountService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("rest/api/account")
public class RestAccountControllerImpl extends RestBaseController implements IRestAccountController {

	@Autowired
	IAccountService accountservice;
	
	@PostMapping("/save")
	@Override
	public RootEntity<DtoAccount> saveAccount(@Valid @RequestBody DtoAccountIU dtoAccountIU) {
		return ok(accountservice.saveAccount(dtoAccountIU));
	}

}
