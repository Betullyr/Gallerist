package com.betuly.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.betuly.controller.IRestAuthenticationController;
import com.betuly.controller.RestBaseController;
import com.betuly.controller.RootEntity;
import com.betuly.dto.AuthRequest;
import com.betuly.dto.AuthResponse;
import com.betuly.dto.DtoUser;
import com.betuly.dto.RefreshTokenRequest;
import com.betuly.service.IAuthenticationService;

import jakarta.validation.Valid;


@RestController
public class RestAuthenticationControllerImpl extends RestBaseController implements IRestAuthenticationController{
	
	@Autowired
	IAuthenticationService authenticationService;
	
	
	@PostMapping(path = "/register")
	@Override
	public RootEntity<DtoUser> register(@Valid @RequestBody AuthRequest input){
		
		//return ok(authenticationService.register(input));
		return ok(authenticationService.register(input));
	}


	@PostMapping(path = "/authenticate")
	@Override
	public RootEntity<AuthResponse> authenticate(@RequestBody AuthRequest input) {
		return ok(authenticationService.authenticate(input)) ;
		
	}
	
	@PostMapping(path = "/refreshToken")
	@Override
	public RootEntity<AuthResponse> refreshToken(@Valid @RequestBody RefreshTokenRequest input) {
		return ok(authenticationService.refreshToken(input));
		
	}
	
	
	

}
