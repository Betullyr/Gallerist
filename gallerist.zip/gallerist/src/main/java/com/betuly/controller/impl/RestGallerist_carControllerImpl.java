package com.betuly.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.betuly.controller.IRestGallerist_CarController;
import com.betuly.controller.RestBaseController;
import com.betuly.controller.RootEntity;
import com.betuly.dto.DtoGallerist_car;
import com.betuly.dto.DtoGallerist_carIU;
import com.betuly.service.IGallerist_carService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/rest/api/gallerist_car")
public class RestGallerist_carControllerImpl extends RestBaseController implements IRestGallerist_CarController{

	@Autowired
	IGallerist_carService gallerist_carService;
	

	@PostMapping("/save")
	@Override
	public RootEntity<DtoGallerist_car> saveGallerist_Car(@Valid @RequestBody DtoGallerist_carIU dtoGallerist_carIU) {
		return ok(gallerist_carService.saveGallerist_car(dtoGallerist_carIU));
	}
	
	
	
	
}
