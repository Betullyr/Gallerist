package com.betuly.dto;

import java.math.BigDecimal;

import com.betuly.enums.CurrencyType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DtoAccount extends DtoBase{
	
	private String accountNo;
	
	private String iban;
	
	private BigDecimal amount;
	
	CurrencyType currencyType;

}
