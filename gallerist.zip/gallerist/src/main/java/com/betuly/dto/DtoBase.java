package com.betuly.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DtoBase {
	
	private Long id;
	
	private Date createTime;

}
