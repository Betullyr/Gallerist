package com.betuly.dto;

import java.math.BigDecimal;

import com.betuly.enums.CarStatusType;
import com.betuly.enums.CurrencyType;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DtoCarIU {
	
	@NotNull
    private String plaka;
	
	@NotNull
	private String brand;
	
	@NotNull
	private String model;
	
	@NotNull
	private Integer productionYear;
	
	@NotNull
	private BigDecimal damagePrice;
	
	@NotNull
	private CurrencyType currencyType;
	
	@NotNull
	private CarStatusType carStatusType;

}
