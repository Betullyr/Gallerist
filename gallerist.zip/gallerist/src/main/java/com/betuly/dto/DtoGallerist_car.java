package com.betuly.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DtoGallerist_car extends DtoBase{
	
	private DtoGallerist gallerist;
	
	private DtoCar car;
	
	
	

}
