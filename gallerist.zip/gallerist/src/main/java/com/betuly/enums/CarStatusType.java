package com.betuly.enums;

public enum CarStatusType {
   SALABLE,
   SALED
}
