package com.betuly.enums;

public enum CurrencyType {
	Tl,USD

}
