package com.betuly.handler;

import java.sql.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Exception <E>{

	private String path;
	
	private Date createTime;
	
	private String hostName;
	
	private E message;
	
}
