package com.betuly.jwt;

import java.security.Key;
import java.util.Date;
import java.util.function.Function;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {
	
    public static final String SECRET_KEY = "74ff1c03cab873d60e622e731e736e5b64f339ea7a51f7a0c2c8b2b10c59dac5060e347c1b810237f9ec9f81b94c256c2f8d50e661c3aeddf0dcc9097b645bae75fb8deeaceb4e0575add4fe05cadcb0e052a89e9b64e4700e04a260e4d516c1ced385b89edc592ae3baf9417ca68fd50d388fbd64e7c77ba6b70ea04580374143e81c14d888e4b0e8efce5d6d503f46b2532fa29d58348dfa2cc913b92c76bc4585d1902007215a4c2abf8de43ba928649993c6b61625e36720a79da69203a3a40593984beb17671c03becd038711ef34adbde8f9609b8c9964404828c219ced1c00985215e377889cb60cb1cbba387090010d0f5938b4e45ec066969a7c248";
 
	
	public String generateToken(UserDetails userDetails) {
		 return Jwts.builder()
		 .setSubject(userDetails.getUsername())
		 .setIssuedAt(new Date())
		 .setExpiration(new Date(System.currentTimeMillis() + 1000*60*60*48))
         .signWith(getKey(), SignatureAlgorithm.HS256)
         .compact();				
		
	}
	
	public <T> T exportToken(String token, Function<Claims, T> claimsFunction) {
		Claims claims = getClaims(token);
		return claimsFunction.apply(claims);
	}
	
	
	public Claims getClaims(String token) {
	    Claims claims = Jwts.parserBuilder()
        .setSigningKey(getKey())
        .build()
        .parseClaimsJws(token).getBody();
		return claims;
		
	}
	
	
	public String getUsernameByToken(String token) {
		return exportToken(token, Claims::getSubject);
	}
	
	public boolean isTokenValid(String token) {
		Date expireDate = exportToken(token, Claims :: getExpiration);
		System.out.print(expireDate);
		return new Date().before(expireDate);
	}
	
	
	
	public Key getKey() {
	  byte[] bytes = Decoders.BASE64.decode(SECRET_KEY);
	    return Keys.hmacShaKeyFor(bytes);  
	  
	}
	
	
	
	
	
}
