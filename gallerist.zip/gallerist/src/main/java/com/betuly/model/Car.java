package com.betuly.model;

import java.math.BigDecimal;

import com.betuly.enums.CarStatusType;
import com.betuly.enums.CurrencyType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "car")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Car extends BaseEntity{

	private String plaka;
	
	private String brand;
	
	private String model;
	
	private Integer productionYear;
	
	private BigDecimal damagePrice;
	
	private CurrencyType currencyType;
	
	@Enumerated(EnumType.STRING)
	private CarStatusType carStatusType;
}
