package com.betuly.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.betuly.model.Gallerist_car;

@Repository
public interface GalleristCarRepository extends JpaRepository<Gallerist_car, Long>{

}
