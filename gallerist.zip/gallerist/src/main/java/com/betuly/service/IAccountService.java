package com.betuly.service;

import com.betuly.dto.DtoAccount;
import com.betuly.dto.DtoAccountIU;


public interface IAccountService {
	
	public DtoAccount saveAccount(DtoAccountIU dtoAccountIU);

}
