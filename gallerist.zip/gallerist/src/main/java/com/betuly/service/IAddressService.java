package com.betuly.service;

import com.betuly.dto.DtoAddress;
import com.betuly.dto.DtoAddressIU;

public interface IAddressService {
	
  public DtoAddress saveAddress(DtoAddressIU dtoAddressIU);

}
