package com.betuly.service;

import com.betuly.dto.AuthRequest;
import com.betuly.dto.AuthResponse;
import com.betuly.dto.DtoUser;
import com.betuly.dto.RefreshTokenRequest;

public interface IAuthenticationService {
	
	public DtoUser register(AuthRequest input);
	
	public AuthResponse authenticate(AuthRequest input);
	
	public AuthResponse refreshToken(RefreshTokenRequest input);

}
