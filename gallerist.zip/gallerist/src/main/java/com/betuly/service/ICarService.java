package com.betuly.service;

import com.betuly.dto.DtoCar;
import com.betuly.dto.DtoCarIU;

public interface ICarService {
	
	public DtoCar saveCar(DtoCarIU dtoCarIU);

}
