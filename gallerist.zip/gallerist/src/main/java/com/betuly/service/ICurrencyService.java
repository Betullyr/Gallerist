package com.betuly.service;

import com.betuly.dto.CurrencyRatesResponse;

public interface ICurrencyService {
	
	public CurrencyRatesResponse getCureCurrencyRates(String startDate, String endDate);

}
