package com.betuly.service;

import com.betuly.dto.DtoCustomer;
import com.betuly.dto.DtoCustomerIU;

public interface ICustomerService {
	
	public DtoCustomer saveCustomer(DtoCustomerIU dtoCustomerIU);

}
