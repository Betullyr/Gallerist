package com.betuly.service;

import com.betuly.dto.DtoGallerist;
import com.betuly.dto.DtoGalleristIU;

public interface IGalleristService {
	
	public DtoGallerist saveGallerist(DtoGalleristIU dtoGalleristIU); 

}
