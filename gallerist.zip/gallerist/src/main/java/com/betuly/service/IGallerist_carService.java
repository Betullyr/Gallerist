package com.betuly.service;

import com.betuly.dto.DtoGallerist_car;
import com.betuly.dto.DtoGallerist_carIU;

public interface IGallerist_carService {
	
	public DtoGallerist_car saveGallerist_car(DtoGallerist_carIU dtoGallerist_carIU);

}
