package com.betuly.service;

import com.betuly.dto.DtoSaledCar;
import com.betuly.dto.DtoSaledCarIU;

public interface ISaledCarService {

	public DtoSaledCar buyCar(DtoSaledCarIU dtoSaledCarIU);
}
