package com.betuly.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.betuly.dto.DtoAccount;
import com.betuly.dto.DtoAccountIU;
import com.betuly.model.Account;
import com.betuly.repository.AccountRepository;
import com.betuly.service.IAccountService;

@Service
public class AccountServiceImpl implements IAccountService{
	
	@Autowired
	AccountRepository accountRepository;
	
	
	private Account createAccount(DtoAccountIU dtoAccountIU) {
		Account account = new Account();
		
		account.setCreateTime(new java.sql.Date(System.currentTimeMillis()));;
		
		BeanUtils.copyProperties(dtoAccountIU, account);
		
		return account;
		
		
	}
	
	

	@Override
	public DtoAccount saveAccount(DtoAccountIU dtoAccountIU) {
		
		Account dbAccount = accountRepository.save(createAccount(dtoAccountIU));
		
		DtoAccount dtoAccount = new DtoAccount();
		
		BeanUtils.copyProperties(dbAccount, dtoAccount);
		
		return dtoAccount;
	}

}
