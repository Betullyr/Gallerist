package com.betuly.service.impl;

import java.sql.Date;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.betuly.dto.DtoAddress;
import com.betuly.dto.DtoAddressIU;
import com.betuly.model.Address;
import com.betuly.repository.AddressRepository;
import com.betuly.service.IAddressService;


@Service
public class AddressServiceImpl implements IAddressService{
	
	@Autowired
	AddressRepository addressRepository;
	
	private Address createAddress(DtoAddressIU dtoAddressIU) {
		Address addres = new Address();
		addres.setCreateTime(new Date(System.currentTimeMillis()));
		
		BeanUtils.copyProperties(dtoAddressIU, addres);
		
		return addres;
		
	}
	
	
	public DtoAddress saveAddress(DtoAddressIU dtoAddressIU){

		
		Address dbAddress = addressRepository.save(createAddress(dtoAddressIU));
		
		DtoAddress dtoAddress = new DtoAddress();
		
		BeanUtils.copyProperties(dbAddress, dtoAddress);
		
		return dtoAddress;
	}

}
