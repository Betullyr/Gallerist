package com.betuly.service.impl;

import java.sql.Date;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.betuly.Exception.BaseException;
import com.betuly.Exception.ErrorMessage;
import com.betuly.Exception.MessageType;
import com.betuly.dto.DtoAccount;
import com.betuly.dto.DtoAddress;
import com.betuly.dto.DtoCustomer;
import com.betuly.dto.DtoCustomerIU;
import com.betuly.model.Account;
import com.betuly.model.Address;
import com.betuly.model.Customer;
import com.betuly.repository.AccountRepository;
import com.betuly.repository.AddressRepository;
import com.betuly.repository.CustomerRepository;
import com.betuly.service.ICustomerService;

@Service
public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	private AddressRepository addressRepository;
	
	@Autowired
	private AccountRepository accountRepository;
	
	
	private Customer createCustomer(DtoCustomerIU dtoCustomerIU) {
		Customer customer = new Customer();
		customer.setCreateTime(new Date(System.currentTimeMillis()));
		
		Optional<Address> addOptional = addressRepository.findById(dtoCustomerIU.getAddressId());
	
		if (addOptional.isEmpty()) {
			throw new BaseException(new ErrorMessage(MessageType.NO_RECORD_EXIST, dtoCustomerIU.getAddressId().toString()));
		}
		
		Optional<Account> accOptional = accountRepository.findById(dtoCustomerIU.getAccountId());
		
		if (accOptional.isEmpty()) {
			throw new BaseException(new ErrorMessage(MessageType.NO_RECORD_EXIST, dtoCustomerIU.getAccountId().toString()));
		}
		
		BeanUtils.copyProperties(dtoCustomerIU, customer);
		
		customer.setAccount(accOptional.get());
		customer.setAddress(addOptional.get());
		
		return customer;
	}

	@Override
	public DtoCustomer saveCustomer(DtoCustomerIU dtoCustomerIU) {
	   Customer dbCustomer = customerRepository.save(createCustomer(dtoCustomerIU));
	   
	   DtoCustomer dtoCustomer = new DtoCustomer();
	   DtoAddress dtoAddress = new DtoAddress();
	   DtoAccount dtoAccount = new DtoAccount();
	   
	   BeanUtils.copyProperties(dbCustomer, dtoCustomer);
	   BeanUtils.copyProperties(dbCustomer.getAccount(), dtoAccount);
	   BeanUtils.copyProperties(dbCustomer.getAddress(), dtoAddress);
	   
	   
	   dtoCustomer.setAccount(dtoAccount);
	   dtoCustomer.setAddress(dtoAddress);
	   
	   
		return dtoCustomer;
	}

}
