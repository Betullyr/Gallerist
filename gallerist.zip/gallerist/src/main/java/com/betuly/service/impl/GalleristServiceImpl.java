package com.betuly.service.impl;

import java.sql.Date;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.betuly.Exception.BaseException;
import com.betuly.Exception.ErrorMessage;
import com.betuly.Exception.MessageType;
import com.betuly.dto.DtoAddress;
import com.betuly.dto.DtoGallerist;
import com.betuly.dto.DtoGalleristIU;
import com.betuly.model.Address;
import com.betuly.model.Gallerist;
import com.betuly.repository.AddressRepository;
import com.betuly.repository.GalleristRepository;
import com.betuly.service.IGalleristService;

@Service
public class GalleristServiceImpl implements IGalleristService{
	
	@Autowired
	GalleristRepository galleristRepository;
	
	@Autowired
	AddressRepository addressRepository;
	
	private Gallerist createGallerist(DtoGalleristIU dtoGalleristIU) {
		Gallerist gallerist = new Gallerist();
		gallerist.setCreateTime(new Date(System.currentTimeMillis()));

	   Optional<Address> addOptional = addressRepository.findById(dtoGalleristIU.getAddressId());
	   
	   if (addOptional.isEmpty()) {
		throw new BaseException(new ErrorMessage(MessageType.NO_RECORD_EXIST, dtoGalleristIU.getAddressId().toString()));
	   }
	   
	   BeanUtils.copyProperties(dtoGalleristIU, gallerist);
	   gallerist.setAddress(addOptional.get());
	   
		return gallerist;
	}

	@Override
	public DtoGallerist saveGallerist(DtoGalleristIU dtoGalleristIU) {
		
		DtoGallerist dtoGallerist = new DtoGallerist();
		DtoAddress dtoAddress = new DtoAddress();
		
		Gallerist dbGallerist = galleristRepository.save(createGallerist(dtoGalleristIU));
		
		BeanUtils.copyProperties(dbGallerist, dtoGallerist);
        BeanUtils.copyProperties(dbGallerist.getAddress(), dtoAddress);
        
        dtoGallerist.setAddress(dtoAddress);
		
		return dtoGallerist;
	}

}
