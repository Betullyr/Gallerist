package com.betuly.service.impl;


import java.sql.Date;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.betuly.Exception.BaseException;
import com.betuly.Exception.ErrorMessage;
import com.betuly.Exception.MessageType;
import com.betuly.dto.DtoAddress;
import com.betuly.dto.DtoCar;
import com.betuly.dto.DtoGallerist;
import com.betuly.dto.DtoGallerist_car;
import com.betuly.dto.DtoGallerist_carIU;
import com.betuly.model.Car;
import com.betuly.model.Gallerist;
import com.betuly.model.Gallerist_car;
import com.betuly.repository.CarRepository;
import com.betuly.repository.GalleristCarRepository;
import com.betuly.repository.GalleristRepository;
import com.betuly.service.IGallerist_carService;

@Service
public class Gallerist_carImpl implements IGallerist_carService{
	
	@Autowired
	GalleristCarRepository galleristCarRepository;
	
	@Autowired
	GalleristRepository galleristRepository;
	
	@Autowired
	CarRepository carRepository;
	
	
	private Gallerist_car createGallerist_car(DtoGallerist_carIU dtoGallerist_carIU) {
		Gallerist_car gallerist_car = new Gallerist_car();
		gallerist_car.setCreateTime(new Date(System.currentTimeMillis()));
		
		Optional<Car> Caroptional = carRepository.findById(dtoGallerist_carIU.getCarid());
		
		Optional<Gallerist> Galoptional = galleristRepository.findById(dtoGallerist_carIU.getGalleristid());
		
		if (Caroptional.isEmpty()) {
			throw new BaseException(new ErrorMessage(MessageType.NO_RECORD_EXIST, dtoGallerist_carIU.getCarid().toString()));
		}
		
		if (Galoptional.isEmpty()) {
			throw new BaseException(new ErrorMessage(MessageType.NO_RECORD_EXIST, dtoGallerist_carIU.getGalleristid().toString()));
		}
		
		
		gallerist_car.setCar(Caroptional.get());
		gallerist_car.setGallerist(Galoptional.get());
		
		return gallerist_car;
		
		
		
	}

	@Override
	public DtoGallerist_car saveGallerist_car(DtoGallerist_carIU dtoGallerist_carIU) {
		
		Gallerist_car gallerist_car = createGallerist_car(dtoGallerist_carIU);
		
		Gallerist_car dbGallerist_car = galleristCarRepository.save(gallerist_car);
		
		
		DtoGallerist_car dtoGallerist_car = new DtoGallerist_car();
		BeanUtils.copyProperties(dbGallerist_car, dtoGallerist_car);
		
		DtoGallerist dtoGallerist = new DtoGallerist();
		DtoCar dtoCar = new DtoCar();
		DtoAddress dtoAddress = new DtoAddress();
		
		BeanUtils.copyProperties(dtoGallerist_car.getCar(), dtoCar);
		BeanUtils.copyProperties(dtoGallerist_car.getGallerist(), dtoGallerist);
		BeanUtils.copyProperties(dtoGallerist_car.getGallerist().getAddress(), dtoAddress);
		
		
		dtoGallerist.setAddress(dtoAddress);
		dtoGallerist_car.setCar(dtoCar);
		dtoGallerist_car.setGallerist(dtoGallerist);
		
		return dtoGallerist_car;
	}
	

}
