package com.betuly.service.impl;

import java.sql.Date;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.betuly.Exception.BaseException;
import com.betuly.Exception.ErrorMessage;
import com.betuly.Exception.MessageType;
import com.betuly.dto.AuthRequest;
import com.betuly.dto.AuthResponse;
import com.betuly.dto.DtoUser;
import com.betuly.dto.RefreshTokenRequest;
import com.betuly.jwt.JwtService;
import com.betuly.model.RefreshToken;
import com.betuly.model.User;
import com.betuly.repository.RefreshTokenRepository;
import com.betuly.repository.UserRepository;
import com.betuly.service.IAuthenticationService;


@Service
public class IAuthenticationServiceImpl implements IAuthenticationService{

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	private AuthenticationProvider authenticationProvider;
	
	@Autowired
	private JwtService jwtService;
	
	@Autowired
	private RefreshTokenRepository refreshTokenRepository;
	
	private User createUser(AuthRequest input) {
		User user = new User();
		user.setCreateTime(new Date(System.currentTimeMillis()));
		user.setUsername(input.getUsername());
		user.setPassword(passwordEncoder.encode(input.getPassword()));
		
		return user;
		
	}
	
	private RefreshToken createRefreshToken(User user) {
		RefreshToken refreshToken = new RefreshToken();
		refreshToken.setCreateTime(new Date(System.currentTimeMillis()));
		refreshToken.setExpireDate (new Date(System.currentTimeMillis() + 1000*60*60*48));
		refreshToken.setRefreshToken(UUID.randomUUID().toString());
		refreshToken.setUser(user);
		
		
		return refreshToken;
	}
	
	@Override
	public DtoUser register(AuthRequest input) {
	   User user = createUser(input);
	   User dbUser = userRepository.save(user);
	   
	   DtoUser dtoUser = new DtoUser();
       BeanUtils.copyProperties(dbUser, dtoUser);
       
       return dtoUser;
	}

	@Override
	public AuthResponse authenticate(AuthRequest input) {
		try {
		  //kullanıcı adı ve password dogru mu	
		  UsernamePasswordAuthenticationToken authenticationToken=
		  new UsernamePasswordAuthenticationToken(input.getUsername(), input.getPassword());
		  
		  authenticationProvider.authenticate(authenticationToken);
		  
		  Optional<User> optional = userRepository.findByUsername(input.getUsername());
		  String accessToken = jwtService.generateToken(optional.get());
		  RefreshToken refreshToken = createRefreshToken(optional.get());
		  
		  RefreshToken save = refreshTokenRepository.save(refreshToken);
		  
		  return new AuthResponse(accessToken,save.getRefreshToken());
		  
			
		} catch (Exception e) {
			throw new BaseException(new ErrorMessage(MessageType.USERNAME_OR_INVALID, e.getMessage()));
		}
		
	}
	
	public Boolean isValidRefreshToken(Date expireDate) {
		return new Date(System.currentTimeMillis()).before(expireDate);
	}

	@Override
	public AuthResponse refreshToken(RefreshTokenRequest input) {
		
		Optional<RefreshToken> byRefreshToken = refreshTokenRepository.findByRefreshToken(input.getRefreshToken());
		
		if (byRefreshToken.isEmpty()) {
			
			throw new BaseException(new ErrorMessage(MessageType.REFRESH_TOKEN_NOT_FOUND, input.getRefreshToken()));
			
		}
		if (!isValidRefreshToken(byRefreshToken.get().getExpireDate())) {
			throw new BaseException(new ErrorMessage(MessageType.REFRESH_TOKEN_IS_EXPIRED, input.getRefreshToken()));
			
		}
		
		User user= byRefreshToken.get().getUser();
		
		String token = jwtService.generateToken(user);
		
		RefreshToken refreshToken = createRefreshToken(user);
		
		RefreshToken save = refreshTokenRepository.save(refreshToken);
		
		
		
		return new AuthResponse(token, refreshToken.getRefreshToken());
	}

	
}
