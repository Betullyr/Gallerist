package com.betuly.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.betuly.Exception.BaseException;
import com.betuly.Exception.ErrorMessage;
import com.betuly.Exception.MessageType;
import com.betuly.dto.CurrencyRatesResponse;
import com.betuly.dto.DtoCar;
import com.betuly.dto.DtoCustomer;
import com.betuly.dto.DtoGallerist;
import com.betuly.dto.DtoSaledCar;
import com.betuly.dto.DtoSaledCarIU;
import com.betuly.enums.CarStatusType;
import com.betuly.model.Car;
import com.betuly.model.Customer;
import com.betuly.model.Saled_car;
import com.betuly.repository.CarRepository;
import com.betuly.repository.CustomerRepository;
import com.betuly.repository.SaledCarRepository;
import com.betuly.service.ICurrencyService;
import com.betuly.service.ISaledCarService;
import com.betuly.utils.DateUtils;

@Service
public class SaledCarServiceImpl implements ISaledCarService{
	
	@Autowired
	private SaledCarRepository saledCarRepository;

	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private CarRepository carRepository;
	
	@Autowired
	private ICurrencyService currencyService;
	
	
	public BigDecimal convertCustomerAmountToUSD(Customer customer) {
		
		CurrencyRatesResponse currencyRatesResponse = currencyService.getCureCurrencyRates(DateUtils.getCurrentDate(new Date(System.currentTimeMillis())), DateUtils.getCurrentDate(new Date(System.currentTimeMillis())));
		
		BigDecimal usd = new BigDecimal((currencyRatesResponse.getItems().get(0).getUsd()));
		
		BigDecimal customerUSD = customer.getAccount().getAmount().divide(usd, 2, RoundingMode.HALF_UP);
		
		return customerUSD;
		
	}
	
	
	public boolean checkCarState(Long carId) {
		Optional<Car> optCar = carRepository.findById(carId);
		if (optCar.isPresent() && optCar.get().getCarStatusType().name().equals(CarStatusType.SALABLE.name())) {
			return false;
		}
		return true;
		
	}
	
	
	
	
	public boolean checkAmount(DtoSaledCarIU dtoSaledCarIU) {
		Optional<Customer> optCustomer = customerRepository.findById(dtoSaledCarIU.getCustomerId());
		
		if (optCustomer.isEmpty()) {
			throw new BaseException(new ErrorMessage(MessageType.NO_RECORD_EXIST,dtoSaledCarIU.getCustomerId().toString()));
			
		}
		
	   Optional<Car> optCar = carRepository.findById(dtoSaledCarIU.getCarId());
	   
	   if (optCar.isEmpty()) {
			throw new BaseException(new ErrorMessage(MessageType.NO_RECORD_EXIST,dtoSaledCarIU.getCarId().toString()));
			
		}
	  
         
	   BigDecimal CustomerAmountUSD = convertCustomerAmountToUSD(optCustomer.get());
	   
	   if (CustomerAmountUSD.compareTo(optCar.get().getDamagePrice())==0 || CustomerAmountUSD.compareTo(optCar.get().getDamagePrice())>0 ) {
		   
		  return true;
	  }
		
		return false;
	}
	
	
	
	private Saled_car createSaledCar(DtoSaledCarIU dtoSaledCarIU) {
		
		Saled_car saled_car = new Saled_car();
		saled_car.setCreateTime(new Date(System.currentTimeMillis()));
		
		saled_car.setCustomer(customerRepository.findById(dtoSaledCarIU.getCustomerId()).orElse(null));
	    saled_car.setCar(carRepository.findById(dtoSaledCarIU.getCarId()).orElse(null));
	    saled_car.setCar(carRepository.findById(dtoSaledCarIU.getGalleristId()).orElse(null));
	    
	    
		return saled_car;
	}
	
	
	public BigDecimal remaingCustomerAmount(Customer customer, Car car) {
		BigDecimal customerUSDAmount = convertCustomerAmountToUSD(customer);
		BigDecimal remaingCustomerUSDAmount = customerUSDAmount.subtract(car.getDamagePrice());
		
		
		CurrencyRatesResponse currencyRatesResponse = currencyService.getCureCurrencyRates(DateUtils.getCurrentDate(new Date(System.currentTimeMillis())), DateUtils.getCurrentDate(new Date(System.currentTimeMillis())));
		BigDecimal usd = new BigDecimal(currencyRatesResponse.getItems().get(0).getUsd());
		
		return remaingCustomerUSDAmount.multiply(usd);
		
	}
	
	
	
	
	@Override
	public DtoSaledCar buyCar(DtoSaledCarIU dtoSaledCarIU) {
		if (!checkAmount(dtoSaledCarIU)) {
		   throw new BaseException(new ErrorMessage(MessageType.CUSTOMER_AMOUNT_IS_ENOUGH, "" ));
		}
		
		if (!checkCarState(dtoSaledCarIU.getCarId())) {
			throw new BaseException(new ErrorMessage(MessageType.CAR_IS_ALREADY_SALED, dtoSaledCarIU.getCarId().toString() ));
		}
		
		else {
			
			Saled_car dbSaled_car = saledCarRepository.save(createSaledCar(dtoSaledCarIU));
			
			Car car = dbSaled_car.getCar();
			car.setCarStatusType(CarStatusType.SALED);
			carRepository.save(car);
			
			
			Customer customer = dbSaled_car.getCustomer();
			customer.getAccount().setAmount(remaingCustomerAmount(customer, car));
			
			return toDTO(dbSaled_car);
		}
		
		
	}
	
	
	public DtoSaledCar toDTO(Saled_car saled_car) {
		DtoSaledCar dtoSaledCar = new DtoSaledCar();
		DtoCustomer dtoCustomer = new DtoCustomer();
		DtoGallerist dtoGallerist = new DtoGallerist();
		DtoCar dtoCar = new DtoCar();
		
		BeanUtils.copyProperties(saled_car, dtoSaledCar);
		BeanUtils.copyProperties(saled_car.getCar(), dtoCar);
		BeanUtils.copyProperties(saled_car.getCustomer(), dtoCustomer);
		BeanUtils.copyProperties(saled_car.getGallerist(), dtoGallerist);
		
		
		dtoSaledCar.setCar(dtoCar);
		dtoSaledCar.setCustomer(dtoCustomer);
		dtoSaledCar.setGallerist(dtoGallerist);
		
		return dtoSaledCar;
				
	}
	
	

}
