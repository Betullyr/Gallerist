package com.betuly.gallerist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GalleristApplicationTests {

	@Test
	void contextLoads() {
	}

}
